from django.shortcuts import render, get_object_or_404
from .forms import ReviewForm
from django.http import HttpResponseRedirect
from django.views import View
from .models import Review
# Create your views here.

class ReviewView(View):
    def get(self, request):
        form = ReviewForm()
        return render(request,"home.html", {"form":form})
    
    
    def post(self, request):
        form = ReviewForm(request.POST)
        print(form)
        if form.is_valid():
            form.save()
        return render(request, "home.html", {"form":form})
        
def thank(request):
    return render(request,"thank_you.html")
        