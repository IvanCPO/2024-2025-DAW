from django.shortcuts import render
from .forms import ReviewForm
from django.http import HttpResponseRedirect
from django.views import View
# Create your views here.

class ReviewView(View):
    def get(self, request):
        form = ReviewForm()
        return render(request,"home.html", {"form":form})
    
    
    def post(self, request):
        form = ReviewForm(request.POST)
        if form.is_valid():
            # form.save()
            print(form.cleaned_data)
            return render(request, "home.html", {"form":form})
        
def thank(request):
    return render(request,"thank_you.html")
        