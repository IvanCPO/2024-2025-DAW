from django import forms

class ReviewForm(forms.Form):
    user_name = forms.CharField(
        required=True,
        widget=forms.TextInput(attrs={'placeholder': 'Enter username'}),
        error_messages={
            "required": "Este campo es necesario para completar el formulario",
        },
        label="Username:")
    
    password = forms.CharField(
        required=True,
        error_messages={
            "required": "Este campo es necesario para completar el formulario",
        },
        widget=forms.TextInput(attrs={'placeholder': "Enter password"}),
    )
    city = forms.CharField(
        label="City of employment:", 
        help_text="Enter city",
        required=False,
        widget=forms.TextInput(attrs={'placeholder': "Enter city"})
        )
    
    
    server_web = forms.ChoiceField(
        widget=forms.Select,
        choices=[(1, "Apache"), (2, "IIS"), (3, "TomCat")],
        label="Web Server"
        )
    
    role = forms.ChoiceField(
        required=False,
        widget=forms.RadioSelect,
        choices=[(1,"Admin"), (2, "Engineer"), (3, "Manager"), (4, "Guest")],
        label="Please specify your role:"
        )
    
    follow = forms.MultipleChoiceField(
        required=False,
        widget=forms.CheckboxSelectMultiple,
        choices=[(1,"Mail"), (2, "Payroll"), (3, "Self-service")],
        label="Please specify your role:"
        )
    
    