
from .forms import ReviewForm, StudentsForm
from .models import Review, Student
from django.views.generic.base import TemplateView
from django.views.generic.edit import FormView
from django.views.generic import ListView, DetailView, UpdateView, DeleteView, CreateView
# Create your views here.


class ReviewView(FormView):
    form_class = ReviewForm
    template_name = "reviews/review.html"
    success_url = "/thank-you"
    
    def form_valid(self, form):
        form.save()
        return super().form_valid(form)
        

class ThankYouView(TemplateView):
    template_name = "reviews/thank_you.html"
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["message"] = "This works!"
        return context
    

class ReviewsListView(ListView):
    template_name = "reviews/review_list.html"
    model = Review
    context_object_name = "reviews"

class SingleReviewsView(DetailView):
    template_name = "reviews/single_review.html"
    model = Review






class StudentCreateView (CreateView):
    model = Student
    form_class = StudentsForm
    template_name = "reviews/student.html"
    success_url = "/thank-you"


class StudentsListView(ListView):
    model = Student
    template_name = "reviews/student_list.html"
    context_object_name = "students"

class UpdateStudentView(UpdateView):
    model = Student
    form_class = StudentsForm
    template_name = "reviews/student_update.html"
    success_url = "/students"

class DeleteStudentView(DeleteView):
    model = Student
    template_name = "reviews/student_delete.html"
    success_url = "/students"
