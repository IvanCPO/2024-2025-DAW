from django.db import models

# Create your models here.
    

class Review (models.Model):
    CHOISE_SERVER = [
        ("apache", "Apache"), 
        ("iis", "IIS"), 
        ("tomcast", "TomCat")
    ]
    
    CHOISE_ROLE = [
        ("admin","Admin"),
        ("engineer", "Engineer"),
        ("manager", "Manager"),
        ("guest", "Guest")
    ]
    
    CHOISE_FOLLOW = [
        ("mail","Mail"),
        ("payroll", "Payroll"),
        ("self_service", "Self-service")
    ]
    
    user_name = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    city = models.CharField(max_length=100)
    server_web = models.CharField(max_length=15, choices=CHOISE_SERVER)
    role = models.CharField(max_length=15, choices=CHOISE_ROLE)
    follow = models.CharField(max_length=15, choices=CHOISE_FOLLOW)