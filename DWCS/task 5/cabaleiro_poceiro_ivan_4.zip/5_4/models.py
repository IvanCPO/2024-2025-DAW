from django.db import models

# Create your models here.

class Review(models.Model):
    user_name = models.CharField(max_length=100)
    review_text = models.TextField()
    rating = models.IntegerField()
    
    def __str__(self):
        return f"{self.user_name} - ({self.rating})"

class Student (models.Model):
    name = models.CharField(max_length=200)
    degree = models.CharField(max_length=100)
    
    def __str__(self):
        return f"{self.name} - ({self.degree})"
    