from django import forms
from .models import Review, Student

# class ReviewForm(forms.Form):
#     user_name = forms.CharField(label="Nome do USUARIO:", max_length=100, error_messages= { 
#         "required": "Your name must not be empty!",
#         "max_length": "Superaste el limite de caracteres"
#         })
#     review_text = forms.CharField(label="Your Feedback", widget=forms.Textarea, max_length=200, error_messages={"max_legth":"Superaste hermano"})
#     rating = forms.IntegerField(label="Your Rating", min_value=1, max_value=5)

class ReviewForm(forms.ModelForm):
    class Meta:
        model = Review
        fields ='__all__'
        # fields = ["user_name,..."]
        labels = {
            "user_name": "Nome do USUARIO:",
            "review_text": "Your Feedback:",
            "rating": "Your Rating:",
        }
        error_messages = {
            "user_name": { 
                "required": "Your name must not be empty!",
                "max_length": "Superaste el limite de caracteres"
            },
            "review_text": {"max_legth":"Superaste hermano"}
        }

class StudentsForm(forms.ModelForm):
    class Meta:
        model = Student
        fields ='__all__'
        labels = {
            "name": "Nome do ESTUDANTE:",
            "degree": "Grado de Estudo:",
        }
        error_messages = {
            "name": { 
                "required": "O campo 'NOME' non pode estar vacio!!",
                "max_length": "Superaste o limite de caracteres"
            },
            "degree": {
                "max_legth":"Superaste o limite de caracteres"
                }
        }