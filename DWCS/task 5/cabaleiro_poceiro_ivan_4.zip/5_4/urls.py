"""
URL configuration for feedback project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path
from . import views

urlpatterns = [
    path('', views.ReviewView.as_view()),
    path('thank-you', views.ThankYouView.as_view()),
    path('reviews', views.ReviewsListView.as_view()),
    path('reviews/<int:pk>', views.SingleReviewsView.as_view()),
    
    
    path('student', views.StudentCreateView.as_view()),
    path('students', views.StudentsListView.as_view(), name="student-list"),
    path('<int:pk>/update', views.UpdateStudentView.as_view(), name="update-student"),
    path('<int:pk>/delete', views.DeleteStudentView.as_view(), name="delete-student"),
]
