from django import forms
from .models import Review


class ReviewForm(forms.ModelForm):
    
    class Meta:
        model = Review
        fields ='__all__'
        # fields = ["user_name,..."]
        labels = {
            "user_name": "Username:",
            "password": "Password:",
            "city": "City of employment:",
            "server_web" : "Web Server",
            "role": "Please specify your role:",
            "follow": "Single Sign-on to the following:"
        }
        error_messages = {
            "user_name": { 
                "required": "Your name must not be empty!",
                "max_length": "Superaste el limite de caracteres"
            },
            "review_text": {"max_legth":"Superaste hermano"}
        }
        widgets = {
            "user_name": forms.TextInput(attrs={'placeholder': 'Enter username'}),
            "password": forms.PasswordInput(attrs={'placeholder': "Enter password"}),
            "city": forms.TextInput(attrs={'placeholder': "Enter city"}),
            "server_web" : forms.Select(choices=Review.CHOISE_SERVER),
            "role": forms.RadioSelect(choices=Review.CHOISE_ROLE),
            "follow": forms.CheckboxSelectMultiple(choices=Review.CHOISE_FOLLOW)
        }

# class ReviewForm(forms.Form):
#     user_name = forms.CharField(
#         required=True,
#         widget=forms.TextInput(attrs={'placeholder': 'Enter username'}),
#         error_messages={
#             "required": "Este campo es necesario para completar el formulario",
#         },
#         label="Username:")
    
#     password = forms.CharField(
#         required=True,
#         error_messages={
#             "required": "Este campo es necesario para completar el formulario",
#         },
#         widget=forms.TextInput(attrs={'placeholder': "Enter password"}),
#     )
#     city = forms.CharField(
#         label="City of employment:", 
#         help_text="Enter city",
#         required=False,
#         widget=forms.TextInput(attrs={'placeholder': "Enter city"})
#         )
    
    
#     server_web = forms.ChoiceField(
#         widget=forms.Select,
#         choices=Review.CHOISE_SERVER,
#         label="Web Server"
#         )
    
#     role = forms.ChoiceField(
#         required=False,
#         widget=forms.RadioSelect,
#         choices=Review.CHOISE_ROLE,
#         label="Please specify your role:"
#         )
    
#     follow = forms.MultipleChoiceField(
#         required=False,
#         widget=forms.CheckboxSelectMultiple,
#         choices=Review.CHOISE_FOLLOW,
#         label="Please specify your role:"
#         )
    
    