from django.shortcuts import render, get_object_or_404, HttpResponseRedirect
from .models import Post
from .forms import CommentForm
from django.views.generic import ListView, DetailView
from django.views import View
from django.urls import reverse

# Create your views here.
# def main (request):
#     posts = Post.objects.all().order_by("-date")[:3]
#     return render(request,"index.html", {"posts":posts})

class StartingPageView (ListView):
    template_name="index.html"
    model = Post
    context_object_name = "posts"
    def queryset(self):
        return Post.objects.all().order_by("-date")[:3]


# def all (request):
#     posts = Post.objects.all().order_by("-date")
#     return render(request,"blog/includes/posts.html", {"posts":posts})

class AllPostView (ListView):
    template_name = "blog/includes/posts.html"
    model = Post
    context_object_name = "posts"


# def detail (request, slug):
#     post = get_object_or_404(Post,slug=slug)
#     return render(request,"detail.html", {"post":post})

# class DetailPostView (DetailView):
#     template_name = "detail.html"
#     model = Post
#     context_object_name = "post"

class DetailPostView (View):
    template_name = "detail.html"
    model = Post
    def is_stored_post(self, request, post_id):
        stored_post = request.session.get("stored_post")
        is_saved_for_later = False
        if post_id in stored_post:
            is_saved_for_later = True
            
        return is_saved_for_later
    def get(self, request, slug):
        post = Post.objects.get(slug=slug)
        context = {
            "post": post,
            "post_tags": post.tag.all(),
            "comment_form": CommentForm(),
            "comments":post.comments.all().order_by("-id"),
            "saved_for_later": self.is_stored_post(request, post.id)
        }
        return render(request, "detail.html", context)
    
    def post(self, request, slug):
        comment_form = CommentForm(request.POST)
        post = Post.objects.get(slug=slug)
        if comment_form.is_valid():
            comment = comment_form.save(commit=False)
            comment.post = post
            comment.save()
            return HttpResponseRedirect(reverse("detail", args=[slug]))


class ReadLaterView (View):
    
    
    def get(self, request):
        stored_post = request.session.get("stored_post")
        context = {}
        if stored_post is None or len(stored_post) ==0 :
            context["posts"] = []
            context["has_posts"] = False
        else:
            posts = Post.objects.filter(id__in=stored_post)
            context["has_posts"] = True
            context["posts"] = posts
            
        return render(request, "stored-posts.html", context)
    
    def post(self, request):
        stored_post = request.session.get("stored_post")
        if stored_post is None:
            stored_post = []
        post_id = int(request.POST["post_id"])
        if post_id not in stored_post:
            stored_post.append(post_id)
        else:
            stored_post.remove(post_id)
        request.session["stored_post"] = stored_post
        return HttpResponseRedirect("/")
